package com.evolveum.demo.model;

public enum EmpType {
	 FTE, PTE, CONTRACTOR, RETIRED;
}
